package com.waref.booth;

import android.app.Activity;
import android.content.Context;
import android.graphics.*;
import android.graphics.pdf.PdfDocument;
import android.os.*;
import android.print.*;
import java.io.*;

public final class PrintEngine {
    private PrintEngine(){}
    public static void printBitmap(Activity a, Bitmap bitmap){
        PrintManager pm=(PrintManager)a.getSystemService(Context.PRINT_SERVICE);
        PrintAttributes.MediaSize fourBySix=new PrintAttributes.MediaSize("WAREF_4X6","4 x 6 in",4000,6000);
        PrintAttributes attrs=new PrintAttributes.Builder().setMediaSize(fourBySix).setColorMode(PrintAttributes.COLOR_MODE_COLOR).setMinMargins(PrintAttributes.Margins.NO_MARGINS).build();
        pm.print("Waref Booth Photo",new BitmapAdapter(bitmap),attrs);
    }
    static class BitmapAdapter extends PrintDocumentAdapter {
        final Bitmap bitmap; PrintAttributes attrs;
        BitmapAdapter(Bitmap b){bitmap=b;}
        @Override public void onLayout(PrintAttributes oldA,PrintAttributes newA,CancellationSignal cs,LayoutResultCallback cb,Bundle extras){ attrs=newA; cb.onLayoutFinished(new PrintDocumentInfo.Builder("waref-booth.pdf").setContentType(PrintDocumentInfo.CONTENT_TYPE_PHOTO).setPageCount(1).build(),true); }
        @Override public void onWrite(PageRange[] pages,ParcelFileDescriptor fd,CancellationSignal cs,WriteResultCallback cb){ PdfDocument pdf=new PdfDocument(); try{ int w=1200,h=1800; PdfDocument.Page page=pdf.startPage(new PdfDocument.PageInfo.Builder(w,h,1).create()); page.getCanvas().drawBitmap(bitmap,null,new Rect(0,0,w,h),new Paint(Paint.FILTER_BITMAP_FLAG)); pdf.finishPage(page); try(OutputStream o=new FileOutputStream(fd.getFileDescriptor())){ pdf.writeTo(o); } cb.onWriteFinished(new PageRange[]{PageRange.ALL_PAGES}); }catch(Exception e){ cb.onWriteFailed(e.getMessage()); }finally{pdf.close();} }
    }
}
