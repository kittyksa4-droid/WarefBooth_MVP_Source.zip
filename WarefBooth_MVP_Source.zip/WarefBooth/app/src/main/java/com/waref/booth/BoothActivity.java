package com.waref.booth;

import android.Manifest;
import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.graphics.*;
import android.hardware.camera2.*;
import android.media.Image;
import android.media.ImageReader;
import android.os.*;
import android.view.*;
import android.widget.*;
import java.nio.ByteBuffer;
import java.util.*;

public class BoothActivity extends Activity {
    private TextureView preview; private TextView overlay; private CameraDevice camera; private CameraCaptureSession session; private ImageReader reader; private HandlerThread thread; private Handler handler; private String camId; private final ArrayList<Bitmap> shots=new ArrayList<>();
    @Override public void onCreate(Bundle b){ super.onCreate(b); Ui.immersive(this); FrameLayout root=new FrameLayout(this); preview=new TextureView(this); root.addView(preview,new FrameLayout.LayoutParams(-1,-1)); overlay=Ui.title(this,"استعد ✨",56); overlay.setTextColor(Color.WHITE); overlay.setShadowLayer(8,2,2,Color.BLACK); root.addView(overlay,new FrameLayout.LayoutParams(-1,-1)); setContentView(root); preview.setSurfaceTextureListener(listener); }
    @Override protected void onResume(){ super.onResume(); startThread(); if(preview.isAvailable()) open(); }
    @Override protected void onPause(){ close(); stopThread(); super.onPause(); }
    private final TextureView.SurfaceTextureListener listener=new TextureView.SurfaceTextureListener(){ public void onSurfaceTextureAvailable(SurfaceTexture s,int w,int h){ open(); } public void onSurfaceTextureSizeChanged(SurfaceTexture s,int w,int h){} public boolean onSurfaceTextureDestroyed(SurfaceTexture s){return true;} public void onSurfaceTextureUpdated(SurfaceTexture s){} };
    private void startThread(){ thread=new HandlerThread("camera"); thread.start(); handler=new Handler(thread.getLooper()); }
    private void stopThread(){ if(thread!=null){ thread.quitSafely(); try{thread.join();}catch(Exception ignored){} thread=null; handler=null; } }
    private void open(){ if(checkSelfPermission(Manifest.permission.CAMERA)!=PackageManager.PERMISSION_GRANTED){ requestPermissions(new String[]{Manifest.permission.CAMERA},50); return; } try{ CameraManager m=(CameraManager)getSystemService(CAMERA_SERVICE); camId=choose(m); CameraCharacteristics cc=m.getCameraCharacteristics(camId); android.util.Size[] sizes=cc.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP).getOutputSizes(ImageFormat.JPEG); android.util.Size s=sizes[0]; reader=ImageReader.newInstance(s.getWidth(),s.getHeight(),ImageFormat.JPEG,2); reader.setOnImageAvailableListener(this::gotImage,handler); m.openCamera(camId,state,handler); }catch(Exception e){ fail(e); } }
    private String choose(CameraManager m)throws Exception{ String fallback=m.getCameraIdList()[0]; for(String id:m.getCameraIdList()){ Integer f=m.getCameraCharacteristics(id).get(CameraCharacteristics.LENS_FACING); if(f!=null&&f==CameraCharacteristics.LENS_FACING_FRONT)return id; } return fallback; }
    private final CameraDevice.StateCallback state=new CameraDevice.StateCallback(){ public void onOpened(CameraDevice c){camera=c; createPreview();} public void onDisconnected(CameraDevice c){c.close();} public void onError(CameraDevice c,int e){c.close();} };
    private void createPreview(){ try{ SurfaceTexture st=preview.getSurfaceTexture(); st.setDefaultBufferSize(1280,720); Surface surface=new Surface(st); camera.createCaptureSession(Arrays.asList(surface,reader.getSurface()),new CameraCaptureSession.StateCallback(){ public void onConfigured(CameraCaptureSession s){session=s; try{ CaptureRequest.Builder b=camera.createCaptureRequest(CameraDevice.TEMPLATE_PREVIEW); b.addTarget(surface); b.set(CaptureRequest.CONTROL_AF_MODE,CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_PICTURE); session.setRepeatingRequest(b.build(),null,handler); runOnUiThread(()->countdown()); }catch(Exception e){fail(e);} } public void onConfigureFailed(CameraCaptureSession s){} },handler); }catch(Exception e){fail(e);} }
    private void countdown(){ final int secs=Prefs.countdown(this); new CountDownTimer(secs*1000L+200,1000){ int n=secs; public void onTick(long ms){ overlay.setText(String.valueOf(n--)); } public void onFinish(){ overlay.setText("📸"); capture(); } }.start(); }
    private void capture(){ try{ CaptureRequest.Builder b=camera.createCaptureRequest(CameraDevice.TEMPLATE_STILL_CAPTURE); b.addTarget(reader.getSurface()); b.set(CaptureRequest.CONTROL_AF_MODE,CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_PICTURE); session.capture(b.build(),null,handler); }catch(Exception e){fail(e);} }
    private void gotImage(ImageReader r){ Image im=r.acquireLatestImage(); if(im==null)return; ByteBuffer buf=im.getPlanes()[0].getBuffer(); byte[] bytes=new byte[buf.remaining()]; buf.get(bytes); im.close(); Bitmap bm=BitmapFactory.decodeByteArray(bytes,0,bytes.length); shots.add(bm); runOnUiThread(()->{ if(shots.size()<Prefs.photoCount(this)){ overlay.setText("الصورة "+shots.size()+" ✓"); new Handler().postDelayed(this::countdown,800); } else finishSession(); }); }
    private void finishSession(){ Bitmap out=TemplateComposer.compose(this,shots,Prefs.layout(this),Prefs.uri(this,"frame")); overlay.setText("تم ✨"); ResultActivity.result=out; Intent i=new Intent(this,ResultActivity.class); startActivity(i); finish(); }
    private void close(){ try{if(session!=null)session.close(); if(camera!=null)camera.close(); if(reader!=null)reader.close();}catch(Exception ignored){} session=null; camera=null; reader=null; }
    private void fail(Exception e){ runOnUiThread(()->Toast.makeText(this,"Camera: "+e.getMessage(),Toast.LENGTH_LONG).show()); }
    @Override public void onRequestPermissionsResult(int r,String[] p,int[] g){ super.onRequestPermissionsResult(r,p,g); if(r==50&&g.length>0&&g[0]==PackageManager.PERMISSION_GRANTED)open(); }
}
