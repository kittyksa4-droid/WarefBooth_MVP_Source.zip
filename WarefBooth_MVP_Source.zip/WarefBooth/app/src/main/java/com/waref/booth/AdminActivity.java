package com.waref.booth;

import android.app.*;
import android.content.*;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.view.*;
import android.widget.*;

public class AdminActivity extends Activity {
    private static final int PICK_BG=10,PICK_START=11,PICK_FRAME=12; private LinearLayout list;
    @Override public void onCreate(Bundle b){ super.onCreate(b); Ui.immersive(this); build(); }
    private void build(){
        ScrollView s=new ScrollView(this); list=new LinearLayout(this); list.setOrientation(LinearLayout.VERTICAL); list.setPadding(60,30,60,50); s.addView(list); setContentView(s);
        list.addView(Ui.title(this,"إدارة Waref Booth",32));
        addPick("تغيير صورة واجهة البرنامج",PICK_BG); addPick("تغيير صورة / تصميم زر البداية",PICK_START); addPick("اختيار فريم الصور من الاستديو",PICK_FRAME);
        addStepper("عدد الصور في الجلسة","photoCount",1,6,Prefs.photoCount(this));
        addStepper("العد التنازلي بالثواني","countdown",1,10,Prefs.countdown(this));
        CheckBox ap=new CheckBox(this); ap.setText("الطباعة تلقائيًا بعد انتهاء الجلسة"); ap.setTextSize(20); ap.setChecked(Prefs.autoPrint(this)); ap.setOnCheckedChangeListener((b,v)->Prefs.p(this).edit().putBoolean("autoPrint",v).apply()); list.addView(ap);
        TextView lt=Ui.title(this,"ترتيب الصور داخل الورقة",22); lt.setGravity(Gravity.START); list.addView(lt);
        RadioGroup rg=new RadioGroup(this); String[] names={"3 صور عمودية","شبكة 2×2","شريط صور"}; String[] vals={"vertical3","grid","strip"}; String cur=Prefs.layout(this);
        for(int i=0;i<names.length;i++){ RadioButton r=new RadioButton(this); r.setText(names[i]); r.setTextSize(19); r.setTag(vals[i]); if(cur.equals(vals[i])) r.setChecked(true); rg.addView(r); }
        rg.setOnCheckedChangeListener((g,id)->{ RadioButton r=g.findViewById(id); if(r!=null) Prefs.p(this).edit().putString("layout",String.valueOf(r.getTag())).apply(); }); list.addView(rg);
        Button pin=Ui.button(this,"تغيير رمز دخول الإدارة"); pin.setOnClickListener(v->changePin()); list.addView(pin);
        Button test=Ui.button(this,"اختبار جلسة التصوير"); test.setOnClickListener(v->startActivity(new Intent(this,BoothActivity.class))); list.addView(test);
        Button reset=Ui.button(this,"استعادة الإعدادات الافتراضية"); reset.setOnClickListener(v->new AlertDialog.Builder(this).setMessage("إرجاع إعدادات Waref Booth للوضع الافتراضي؟").setPositiveButton("نعم",(d,w)->{ Prefs.p(this).edit().clear().apply(); recreate(); }).setNegativeButton("لا",null).show()); list.addView(reset);
    }
    private void addPick(String label,int code){ Button b=Ui.button(this,label+"  ← الاستديو"); b.setOnClickListener(v->pick(code)); list.addView(b); }
    private void addStepper(String label,String key,int min,int max,int initial){ LinearLayout row=new LinearLayout(this); row.setGravity(Gravity.CENTER_VERTICAL); TextView t=Ui.title(this,label+": "+initial,20); t.setGravity(Gravity.START); row.addView(t,new LinearLayout.LayoutParams(0,-2,1)); Button minus=Ui.button(this,"−"); Button plus=Ui.button(this,"+"); final int[] val={initial}; minus.setOnClickListener(v->{ val[0]=Math.max(min,val[0]-1); t.setText(label+": "+val[0]); Prefs.p(this).edit().putInt(key,val[0]).apply(); }); plus.setOnClickListener(v->{ val[0]=Math.min(max,val[0]+1); t.setText(label+": "+val[0]); Prefs.p(this).edit().putInt(key,val[0]).apply(); }); row.addView(minus,new LinearLayout.LayoutParams(100,80)); row.addView(plus,new LinearLayout.LayoutParams(100,80)); list.addView(row); }
    private void pick(int code){ Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT); i.setType("image/*"); i.addCategory(Intent.CATEGORY_OPENABLE); i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION); startActivityForResult(i,code); }
    @Override protected void onActivityResult(int req,int res,Intent data){ super.onActivityResult(req,res,data); if(res!=RESULT_OK||data==null||data.getData()==null)return; Uri u=data.getData(); try{ getContentResolver().takePersistableUriPermission(u,Intent.FLAG_GRANT_READ_URI_PERMISSION); }catch(Exception ignored){} String key=req==PICK_BG?"homeBg":req==PICK_START?"startArt":"frame"; Prefs.p(this).edit().putString(key,u.toString()).apply(); Toast.makeText(this,"تم الحفظ من الاستديو",Toast.LENGTH_SHORT).show(); }
    private void changePin(){ EditText e=new EditText(this); e.setHint("PIN جديد"); e.setInputType(2); new AlertDialog.Builder(this).setTitle("تغيير الرمز").setView(e).setPositiveButton("حفظ",(d,w)->{ String p=e.getText().toString(); if(p.length()>=4) Prefs.p(this).edit().putString("pin",p).apply(); }).setNegativeButton("إلغاء",null).show(); }
}
