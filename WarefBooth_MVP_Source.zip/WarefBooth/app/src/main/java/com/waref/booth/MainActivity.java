package com.waref.booth;

import android.app.*;
import android.content.*;
import android.graphics.Color;
import android.os.Bundle;
import android.text.InputType;
import android.view.*;
import android.widget.*;

public class MainActivity extends Activity {
    private ImageView bg, startArt;
    @Override public void onCreate(Bundle b){ super.onCreate(b); build(); }
    @Override protected void onResume(){ super.onResume(); Ui.immersive(this); refresh(); }
    private void build(){
        FrameLayout root=new FrameLayout(this); root.setBackgroundColor(Color.rgb(245,239,232));
        bg=new ImageView(this); bg.setScaleType(ImageView.ScaleType.CENTER_CROP); root.addView(bg,new FrameLayout.LayoutParams(-1,-1));
        LinearLayout center=new LinearLayout(this); center.setOrientation(LinearLayout.VERTICAL); center.setGravity(Gravity.CENTER); center.setPadding(80,40,80,40);
        TextView logo=Ui.title(this,"WAREF BOOTH",44); logo.setOnLongClickListener(v->{ pin(); return true; }); center.addView(logo,new LinearLayout.LayoutParams(-2,-2));
        TextView sub=Ui.title(this,"صوّر لحظتك ✨",24); center.addView(sub,new LinearLayout.LayoutParams(-2,-2));
        startArt=new ImageView(this); startArt.setAdjustViewBounds(true); center.addView(startArt,new LinearLayout.LayoutParams(380,180));
        Button start=Ui.button(this,"ابدأ التصوير"); start.setOnClickListener(v->startActivity(new Intent(this,BoothActivity.class))); LinearLayout.LayoutParams bp=new LinearLayout.LayoutParams(420,90); bp.topMargin=24; center.addView(start,bp);
        FrameLayout.LayoutParams cp=new FrameLayout.LayoutParams(-1,-1); root.addView(center,cp); setContentView(root);
    }
    private void refresh(){ Ui.load(bg,this,Prefs.uri(this,"homeBg")); Ui.load(startArt,this,Prefs.uri(this,"startArt")); }
    private void pin(){
        final EditText e=new EditText(this); e.setHint("PIN"); e.setInputType(InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_VARIATION_PASSWORD);
        new AlertDialog.Builder(this).setTitle("إعدادات Waref Booth").setView(e).setPositiveButton("دخول",(d,w)->{ if(e.getText().toString().equals(Prefs.pin(this))) startActivity(new Intent(this,AdminActivity.class)); else Toast.makeText(this,"الرمز غير صحيح",Toast.LENGTH_SHORT).show(); }).setNegativeButton("إلغاء",null).show();
    }
}
