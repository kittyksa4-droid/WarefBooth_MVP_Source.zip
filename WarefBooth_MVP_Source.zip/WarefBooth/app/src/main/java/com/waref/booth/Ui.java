package com.waref.booth;

import android.app.Activity;
import android.content.Context;
import android.graphics.Color;
import android.net.Uri;
import android.provider.Settings;
import android.view.*;
import android.widget.*;
import java.io.InputStream;

public final class Ui {
    private Ui(){}
    public static TextView title(Context c,String s,int sp){ TextView v=new TextView(c); v.setText(s); v.setTextSize(sp); v.setTextColor(Color.rgb(54,39,34)); v.setGravity(Gravity.CENTER); v.setPadding(16,16,16,16); return v; }
    public static Button button(Context c,String s){ Button b=new Button(c); b.setText(s); b.setTextSize(18); b.setAllCaps(false); return b; }
    public static void immersive(Activity a){ a.getWindow().getDecorView().setSystemUiVisibility(5894|View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY); }
    public static void load(ImageView v, Context c, String raw){ if(raw==null||raw.isEmpty()) return; try(InputStream in=c.getContentResolver().openInputStream(Uri.parse(raw))){ v.setImageURI(Uri.parse(raw)); v.setScaleType(ImageView.ScaleType.CENTER_CROP); }catch(Exception ignored){} }
}
