package com.waref.booth;

import android.app.*;
import android.content.*;
import android.graphics.*;
import android.os.Bundle;
import android.view.*;
import android.widget.*;

public class ResultActivity extends Activity {
    public static Bitmap result;
    @Override public void onCreate(Bundle b){ super.onCreate(b); Ui.immersive(this); LinearLayout l=new LinearLayout(this); l.setOrientation(LinearLayout.HORIZONTAL); l.setGravity(Gravity.CENTER); l.setPadding(30,30,30,30); ImageView im=new ImageView(this); im.setImageBitmap(result); im.setScaleType(ImageView.ScaleType.FIT_CENTER); l.addView(im,new LinearLayout.LayoutParams(0,-1,1)); LinearLayout side=new LinearLayout(this); side.setOrientation(LinearLayout.VERTICAL); side.setGravity(Gravity.CENTER); TextView t=Ui.title(this,"صورتك جاهزة ✨",28); side.addView(t); Button print=Ui.button(this,"طباعة الآن"); print.setOnClickListener(v->PrintEngine.printBitmap(this,result)); side.addView(print,new LinearLayout.LayoutParams(330,90)); Button done=Ui.button(this,"إنهاء"); done.setOnClickListener(v->{ startActivity(new Intent(this,MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP)); finish(); }); side.addView(done,new LinearLayout.LayoutParams(330,90)); l.addView(side,new LinearLayout.LayoutParams(380,-1)); setContentView(l); if(Prefs.autoPrint(this)) new Handler().postDelayed(()->PrintEngine.printBitmap(this,result),700); }
}
