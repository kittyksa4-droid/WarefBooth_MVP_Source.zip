package com.waref.booth;

import android.content.Context;
import android.graphics.*;
import android.net.Uri;
import java.io.InputStream;
import java.util.*;

public final class TemplateComposer {
    private TemplateComposer(){}
    public static Bitmap compose(Context c, ArrayList<Bitmap> src,String layout,String frameUri){
        int W=1200,H=1800; Bitmap out=Bitmap.createBitmap(W,H,Bitmap.Config.ARGB_8888); Canvas cv=new Canvas(out); cv.drawColor(Color.WHITE); Paint p=new Paint(Paint.ANTI_ALIAS_FLAG|Paint.FILTER_BITMAP_FLAG);
        ArrayList<Rect> rects=new ArrayList<>(); int n=src.size();
        if("grid".equals(layout)){ int gap=45, cw=(W-gap*3)/2,ch=(H-gap*3)/2; for(int i=0;i<n;i++){ int col=i%2,row=i/2; rects.add(new Rect(gap+col*(cw+gap),gap+row*(ch+gap),gap+col*(cw+gap)+cw,gap+row*(ch+gap)+ch)); } }
        else if("strip".equals(layout)){ int gap=35,ch=(H-gap*(n+1))/Math.max(1,n); for(int i=0;i<n;i++) rects.add(new Rect(120,gap+i*(ch+gap),W-120,gap+i*(ch+gap)+ch)); }
        else { int gap=50,ch=(H-gap*(n+1))/Math.max(1,n); for(int i=0;i<n;i++) rects.add(new Rect(90,gap+i*(ch+gap),W-90,gap+i*(ch+gap)+ch)); }
        for(int i=0;i<src.size()&&i<rects.size();i++) drawCrop(cv,src.get(i),rects.get(i),p);
        if(frameUri!=null&&!frameUri.isEmpty()){ try(InputStream in=c.getContentResolver().openInputStream(Uri.parse(frameUri))){ Bitmap f=BitmapFactory.decodeStream(in); cv.drawBitmap(f,null,new Rect(0,0,W,H),p); }catch(Exception ignored){} }
        return out;
    }
    private static void drawCrop(Canvas c,Bitmap b,Rect dst,Paint p){ float sr=(float)b.getWidth()/b.getHeight(), dr=(float)dst.width()/dst.height(); Rect src; if(sr>dr){ int nw=(int)(b.getHeight()*dr),x=(b.getWidth()-nw)/2; src=new Rect(x,0,x+nw,b.getHeight()); }else{ int nh=(int)(b.getWidth()/dr),y=(b.getHeight()-nh)/2; src=new Rect(0,y,b.getWidth(),y+nh); } c.drawBitmap(b,src,dst,p); }
}
