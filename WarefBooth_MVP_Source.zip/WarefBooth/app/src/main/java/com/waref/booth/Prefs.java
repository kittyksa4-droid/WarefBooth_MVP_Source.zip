package com.waref.booth;

import android.content.Context;
import android.content.SharedPreferences;

public final class Prefs {
    private static final String N="waref_booth";
    private Prefs(){}
    public static SharedPreferences p(Context c){ return c.getSharedPreferences(N, Context.MODE_PRIVATE); }
    public static String pin(Context c){ return p(c).getString("pin","8888"); }
    public static int photoCount(Context c){ return p(c).getInt("photoCount",3); }
    public static boolean autoPrint(Context c){ return p(c).getBoolean("autoPrint",true); }
    public static int countdown(Context c){ return p(c).getInt("countdown",3); }
    public static String layout(Context c){ return p(c).getString("layout","vertical3"); }
    public static String uri(Context c,String key){ return p(c).getString(key,""); }
}
