# Waref Booth — Android MVP

نسخة أولية Native Android لفوتوبوث وارف.

## الموجود الآن
- واجهة عميل Waref Booth بوضع ملء الشاشة.
- دخول الإدارة مخفي: ضغط مطول على WAREF BOOTH ثم PIN افتراضي 8888.
- تغيير خلفية الواجهة، صورة زر البداية، وفريم الطباعة من الاستديو.
- تغيير عدد الصور 1–6، العد التنازلي، ترتيب الصور، والطباعة التلقائية.
- كاميرا أمامية + Live Preview + تصوير متتابع.
- تكوين قالب 4×6 بثلاثة Presets.
- Android Print Framework مع مقاس 4×6؛ يظهر نظام الطباعة لاختيار PIXMA TS3640/Mopria.
- لا يتم حفظ صور الجلسة في Gallery.

## البناء
افتح المجلد في Android Studio Quail 3 أو أحدث، ثبّت Android SDK 36، ثم Sync/Build APK.

## مهم للطباعة
Android PrintManager يفتح واجهة الطباعة النظامية للتأكيد/اختيار الطابعة. الطباعة الصامتة 100% تحتاج مسار Direct Print أو تكامل خاص بخدمة الطباعة/الطابعة، لذلك PrintEngine منفصل ليسهل استبداله لاحقًا.

## التالي المقترح
- محرر حر Drag/Resize لكل خانة صورة بدل Presets فقط.
- إعدادات قص/Zoom/Mirror لكل خانة.
- قفل Kiosk/Lock Task أقوى.
- Direct Print تجريبي إلى TS3640 بعد اختبار الطابعة على نفس شبكة Wi‑Fi.
- QR download / GIF / Boomerang / filters.
